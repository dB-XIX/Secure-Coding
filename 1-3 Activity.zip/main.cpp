// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="overflowDetected">Flag to indicate overflow detection</param>
/// <returns>start + (increment * steps)</returns>

// Declaration of the add_numbers function
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps, bool& overflowDetected); // Added bool for calling function

// Definition of the add_numbers function
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps, bool& overflowDetected) // Added bool for calling function
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for potential overflow before addition
        if (increment > 0 && std::numeric_limits<T>::max() - result < increment) { // Using numeric_limits<T>::max() from <limits>
            std::cout << "Overflow Detected" << std::endl <<
                "\tThe maximum value before overflow is " << +std::numeric_limits<T>::max() << "." << std::endl;
            overflowDetected = true; // Set the overflow flag
            return result; // Return the current result without modifying it
        }
        else {
            result += increment; // Perform addition
        }
    }

    // Return the result if no overflow occurred
    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="underflowDetected">Flag to indicate underflow detection</param>
/// <returns>start - (increment * steps)</returns>

// Declaration of the subtract_numbers function
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, bool& underflowDetected); // Added bool for calling function

// Definition of the subtract_numbers function
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, bool& underflowDetected) // Added bool for calling function
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for potential underflow before subtraction
        if (result < decrement) {
            std::cout << "Underflow Detected" << std::endl <<
                "\tThe minimum value before underflow is " << +std::numeric_limits<T>::min() << "." << std::endl;
            underflowDetected = true; // Set the underflow flag
            return result; // Return the current result without modifying it
        }
        else {
            result -= decrement; // Perform subtraction
        }
    }

    // Return the result if no underflow occurred
    return result;
}

//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 4; // Changed from 5 to 4 for proper operation
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;
    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Declare overflowDetected variable
    bool overflowDetected = false;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result = add_numbers<T>(start, increment, steps, overflowDetected);
    std::cout << +result << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1, overflowDetected);

    std::cout << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we subtract each step (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    // Declare underflowDetected variable
    bool underflowDetected = false;

    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    auto result = subtract_numbers<T>(start, decrement, steps, underflowDetected);
    std::cout << +result << std::endl;

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1, underflowDetected);

    std::cout << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();
}

int main()
{
    //  create a string of "*" to use in the console
    const std::string star_line = std::string(50, '*');

    // Michael Berry \m/
    std::cout << "\tStarting Numeric Underflow / Overflow Tests!" << std::endl;

    // run the overflow tests
    do_overflow_tests(star_line);

    // run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}